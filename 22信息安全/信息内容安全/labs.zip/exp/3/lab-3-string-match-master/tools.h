#ifndef TOOLS_H
#define TOOLS_H

void print_memory_usage();

#endif