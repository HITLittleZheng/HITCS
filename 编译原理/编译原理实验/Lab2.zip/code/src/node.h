#ifndef _MY_NODE_H_
#define _MY_NODE_H_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <stdarg.h>

#define MAX_CHILD_NUM 7
extern int yylineno;
// 抽象语法树
typedef struct Abstract_Tree
{
    char name[32];                              // 节点名称
    char text[32];                              // 节点文本内容
    int lineno;                                 // 节点所在行号
    int childsum;                               // 子节点数量
    struct Abstract_Tree *child[MAX_CHILD_NUM]; // 子节点数组
} Node;

Node *createNode(char *name, char *text);       // 创建节点
void addChild(int childsum, Node *parent, ...); // 添加子节点
void printTree(Node *root, int blank);          // 打印抽象语法树

#endif
