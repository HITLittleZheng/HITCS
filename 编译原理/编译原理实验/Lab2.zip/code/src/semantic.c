#include "node.h"     // 包含节点头文件
#include "semantic.h" // 包含语义头文件

FieldList hashTable[HASH_SIZE]; // 哈希表数组

unsigned int hash_pjw(char *name)
{ // PJW哈希算法函数
    unsigned int val = 0, i;
    for (; *name; ++name)
    {                             // 遍历字符串名字
        val = (val << 2) + *name; // 更新哈希值
        if (i = val & ~0x3fff)
        {                                     // 如果存在高位溢出
            val = (val ^ (i >> 12)) & 0x3fff; // 则进行一次异或操作
        }
        return val % HASH_SIZE; // 返回哈希值
    }
}

void initHashtable()
{ // 初始化哈希表函数
    for (int i = 0; i < HASH_SIZE; i++)
    {                        // 遍历哈希表数组
        hashTable[i] = NULL; // 将每个位置初始化为空
    }
}

int insertSymbol(FieldList f)
{                                    // 插入符号函数
    if (f == NULL)                   // 如果字段列表为空
        return 0;                    // 返回失败
    if (f->name == NULL)             // 如果字段名称为空
        return 0;                    // 返回失败
    f->collision = 0;                // 碰撞次数初始化为0
    unsigned int key;                // 声明哈希键变量
    if (f->type->kind == 3)          // 如果类型为函数类型
        key = hash_pjw(1 + f->name); // 计算哈希键
    else
        key = hash_pjw(f->name); // 否则计算哈希键
    if (hashTable[key] == NULL)
    {                       // 如果哈希表对应位置为空
        hashTable[key] = f; // 将字段列表插入该位置
        return 1;           // 返回成功
    }

    while (1)
    {                                    // 循环直到找到合适位置
        key = (++key) % HASH_SIZE;       // 更新哈希键
        f->collision = f->collision + 1; // 更新碰撞次数
        if (hashTable[key] == NULL)
        {                       // 如果找到空位置
            hashTable[key] = f; // 将字段列表插入该位置
            return 1;           // 返回成功
        }
    }
    return 0; // 返回失败
}

FieldList lookupSymbol(char *name, int function)
{ // 查找符号函数
    if (name == NULL)
    {                // 如果名称为空
        return NULL; // 返回空
    }
    unsigned int key;             // 声明哈希键变量
    if (function)                 // 如果是函数
        key = hash_pjw(1 + name); // 计算哈希键
    else
        key = hash_pjw(name);     // 否则计算哈希键
    FieldList p = hashTable[key]; // 从哈希表中获取对应位置的字段列表
    while (p != NULL)
    { // 循环查找
        if (strcmp(name, p->name) == 0)
        {                                                       // 如果找到名称相同的字段列表
            if ((function == 1) && (p->type->kind == FUNCTION)) // 如果是函数类型
                return p;                                       // 返回该字段列表
            if ((function == 0) && (p->type->kind != FUNCTION)) // 如果不是函数类型
                return p;                                       // 返回该字段列表
        }
        key = (++key) % HASH_SIZE; // 更新哈希键
        p = hashTable[key];        // 获取下一个位置的字段列表
    }
    return NULL; // 如果找不到，则返回空
}

void AllSymbol()
{ // 查看所有符号函数
    for (int i = 0; i < HASH_SIZE; i++)
    { // 遍历哈希表
        if (hashTable[i] != NULL)
        {                                                                                 // 如果哈希表当前位置不为空
            printf("name: %s, kind: %d\n", hashTable[i]->name, hashTable[i]->type->kind); // 打印字段名称和类型
        }
    }
}

int TypeEqual(TypePtr type1, TypePtr type2)
{                                           // 判断类型是否相等函数
    if ((type1 == NULL) || (type2 == NULL)) // 如果其中一个类型为空
        return 0;                           // 返回不相等
    if (type1->kind != type2->kind)         // 如果类型种类不同
        return 0;                           // 返回不相等
    else
        switch (type1->kind)
        { // 根据类型种类进行判断
        case BASIC:
        {                                           // 基本类型
            if (type1->u.basic_ == type2->u.basic_) // 如果基本类型相同
                return 1;                           // 返回相等
            else
                return 0; // 返回不相等
        }
        break;
        case ARRAY:
        {                                                                   // 数组类型
            if (TypeEqual(type1->u.array_.elem, type2->u.array_.elem) == 1) // 如果数组元素类型相同
                return 1;                                                   // 返回相等
            else
                return 0; // 返回不相等
        }
        break;
        case STRUCTURE:
        {                                           // 结构体类型
            FieldList field1 = type1->u.structure_; // 获取结构体字段列表
            FieldList field2 = type2->u.structure_; // 获取结构体字段列表
            if ((field1 != NULL) && (field2 != NULL))
            { // 如果两个结构体字段列表都不为空
                while ((field1 != NULL) && (field2 != NULL))
                { // 循环比较每个字段
                    if (TypeEqual(field1->type, field2->type) == 0)
                    {             // 如果字段类型不相等
                        return 0; // 返回不相等
                    }
                    field1 = field1->tail; // 获取下一个字段
                    field2 = field2->tail; // 获取下一个字段
                }
                if ((field1 == NULL) && (field2 == NULL)) // 如果两个结构体字段列表都为空
                    return 1;                             // 返回相等
            }
            return 0; // 返回不相等
        }
        break;
        case FUNCTION:
        {                                                                   // 函数类型
            if (type1->u.function_.paramNum != type2->u.function_.paramNum) // 如果函数参数个数不同
                return 0;                                                   // 返回不相等
            FieldList param1 = type1->u.function_.params;                   // 获取函数参数列表
            FieldList param2 = type2->u.function_.params;                   // 获取函数参数列表
            for (int i = 0; i < type1->u.function_.paramNum; i++)
            {                                                   // 循环比较每个参数类型
                if (TypeEqual(param1->type, param2->type) == 0) // 如果参数类型不相等
                    return 0;                                   // 返回不相等
                param1 = param1->tail;                          // 获取下一个参数
                param2 = param2->tail;                          // 获取下一个参数
            }
            return 1; // 返回相等
        }
        break;
        default:
        {             // 默认情况
            return 0; // 返回不相等
        }
        break;
        }
}

// 根据变量声明的语法树节点，构造变量的类型信息 支持基本类型、一维数组和二维数组的声明。
FieldList VarDec(Node *root, TypePtr basictype)
{
    Node *temp = root; // 临时节点指针指向根节点
    int i = 0;         // 初始化计数器，用于记录当前节点是在多少级别的嵌套下
    while (strcmp(temp->child[0]->name, "ID") != 0)
    {                          // 循环直到找到ID节点
        temp = temp->child[0]; // 移动到第一个子节点
        i++;                   // 计数器加一
    }
    char *s = temp->child[0]->text; // 获取ID节点的文本内容，即变量名

    FieldList field = (FieldList)malloc(sizeof(FieldList_)); // 分配字段列表内存
    field->name = s;                                         // 将字段名称设置为ID节点的文本内容

    if (strcmp(root->child[0]->name, "ID") == 0)
    {                            // 如果根节点是ID节点
        field->type = basictype; // 将字段类型设置为基本类型
        return field;            // 返回字段列表
    }

    switch (i)
    { // 根据计数器值进行分支判断，允许2行数组
    case 1:
    {
        TypePtr var1 = (TypePtr)malloc(sizeof(Type_));    // 分配类型内存
        var1->kind = ARRAY;                               // 设置类型种类为数组
        var1->u.array_.size = atoi(root->child[2]->text); // 设置数组大小
        var1->u.array_.elem = basictype;                  // 设置数组元素类型
        field->type = var1;                               // 将字段类型设置为数组类型
        return field;                                     // 返回字段列表
    }
    break;
    case 2:
    {
        // 外层数组
        TypePtr var1 = (TypePtr)malloc(sizeof(Type_));              // 分配类型内存
        var1->kind = ARRAY;                                         // 设置类型种类为数组
        var1->u.array_.size = atoi(root->child[2]->text);           // 设置数组大小
        var1->u.array_.elem = basictype;                            // 设置数组元素类型
       //内层数组
        TypePtr var2 = (TypePtr)malloc(sizeof(Type_));              // 分配类型内存
        var2->kind = ARRAY;                                         // 设置类型种类为数组
        var2->u.array_.size = atoi(root->child[0]->child[2]->text); // 设置数组大小
        var2->u.array_.elem = var1;                                 // 设置数组元素类型为var1
        field->type = var2;                                         // 将字段类型设置为数组类型
        return field;                                               // 返回字段列表
    }
    break;
    default:
        printf("error in VarDec");
        break; // 默认情况下输出错误信息
    }
}

// 根据类型声明的语法树节点，解析并生成对应的类型信息，支持基本类型和结构体类型。
TypePtr Specifier(Node *root)
{
    // Specifier → TYPE
    TypePtr spe = (TypePtr)malloc(sizeof(Type_)); // 分配类型内存
    if (strcmp(root->child[0]->name, "TYPE") == 0)
    {                                                 // 如果根节点是TYPE节点
        spe->kind = BASIC;                            // 设置类型种类为基本类型
        if (strcmp(root->child[0]->text, "int") == 0) // 如果类型文本内容为int
            spe->u.basic_ = INT_TYPE;                 // 设置基本类型为INT_TYPE
        else
            spe->u.basic_ = FLOAT_TYPE; // 设置基本类型为FLOAT_TYPE
        return spe;                     // 返回类型指针
    }
    // Specifier -> StructSpecifier
    /*
       StructSpecifier → STRUCT OptTag LC DefList RC | STRUCT Tag
       OptTag → ID | e
       Tag → ID
       */
    else
    {
        spe->kind = STRUCTURE; // 设置类型种类为结构体类型
        if (root->child[0]->childsum == 2)
        {                                                       // 如果存在Tag节点
            char *s = root->child[0]->child[1]->child[0]->text; // 获取Tag节点的名称
            FieldList field = lookupSymbol(s, 0);               // 在符号表中查找该名称对应的字段列表
            if (field == NULL)
            {                                                                                       // 如果字段列表为空
                printf("Error type 17 at Line %d: Undefined structure \"%s\".\n", root->lineno, s); // 输出错误信息
                spe->u.structure_ = NULL;                                                           // 设置结构体类型字段列表为空
                return spe;                                                                         // 返回结构体类型指针
            }
            else if (field->type != NULL) // 如果字段列表的类型不为空
                return field->type;       // 返回字段列表的类型
            spe->u.structure_ = NULL;     // 设置结构体类型字段列表为空
            return spe;                   // 返回结构体类型指针
        }
        else
        {                                             // 如果不存在Tag节点，表示是匿名结构体，需要处理结构体定义列表
            Node *DefList = root->child[0]->child[3]; // 获取DefList节点
            spe->u.structure_ = NULL;                 // 设置结构体类型字段列表为空
            // 在结构体内的DefList与外部的不同
            /*
           DefList → Def DefList | e
           Def →Specifier DecList  SEMI
           DecList → Dec | Dec COMMA DecList
           Dec → VarDec | VarDec ASSIGNOP Exp
           */
            while (DefList != NULL)
            {                                                 // 循环处理每个Def节点
                Node *Def = DefList->child[0];                // 获取Def节点
                TypePtr basictype = Specifier(Def->child[0]); // 递归调用Specifier获取基本类型

                Node *DecList = Def->child[1]; // 获取DecList节点
                while (DecList->childsum == 3)
                {                                                                                                              // 如果还有下一个Dec节点
                    FieldList field = VarDec(DecList->child[0]->child[0], basictype);                                          // 调用VarDec获取字段列表
                    if (DecList->child[0]->childsum != 1)                                                                      // 如果Dec节点的子节点数不为1，即有初始化
                        printf("Error type 15 at Line %d: Variable %s in struct is initialized.\n", Def->lineno, field->name); // 输出错误信息
                    FieldList temp = spe->u.structure_;                                                                        // 临时字段列表指针指向结构体类型字段列表
                    while (temp != NULL)
                    { // 循环检查是否存在重定义的字段
                        if (strcmp(temp->name, field->name) == 0)
                        {                                                                                            // 如果字段名称重复
                            printf("Error type 15 at Line %d: Redefined field \"%s\".\n", Def->lineno, field->name); // 输出错误信息
                            break;                                                                                   // 跳出循环
                        }
                        temp = temp->tail; // 移动到下一个字段
                    }
                    if (temp == NULL)
                    {                                                                                                  // 如果未找到重定义的字段
                        if (lookupSymbol(field->name, 0) != NULL)                                                      // 如果在符号表中找到了同名的变量
                            printf("Error type 3 at Line %d: Redefined variable \"%s\".\n", Def->lineno, field->name); // 输出错误信息
                        else
                        {                                    // 如果未找到同名的变量
                            insertSymbol(field);             // 在符号表中插入字段列表
                            field->tail = spe->u.structure_; // 将字段列表加入到结构体类型的字段列表中
                            spe->u.structure_ = field;       // 更新结构体类型的字段列表
                        }
                    }
                    DecList = DecList->child[2]; // 获取下一个Dec节点
                }
                FieldList field = VarDec(DecList->child[0]->child[0], basictype);                                              // 调用VarDec获取字段列表
                if (DecList->child[0]->childsum != 1)                                                                          // 如果Dec节点的子节点数不为1，即有初始化
                    printf("Error type 15 at Line %d: Variable \"%s\" in struct is initialized.\n", Def->lineno, field->name); // 输出错误信息
                FieldList temp = spe->u.structure_;                                                                            // 临时字段列表指针指向结构体类型字段列表
                while (temp != NULL)
                { // 循环检查是否存在重定义的字段
                    if (strcmp(temp->name, field->name) == 0)
                    {                                                                                            // 如果字段名称重复
                        printf("Error type 15 at Line %d: Redefined field \"%s\".\n", Def->lineno, field->name); // 输出错误信息
                        break;                                                                                   // 跳出循环
                    }
                    temp = temp->tail; // 移动到下一个字段
                }
                if (temp == NULL)
                {                                                                                                  // 如果未找到重定义的字段
                    if (lookupSymbol(field->name, 0) != NULL)                                                      // 如果在符号表中找到了同名的变量
                        printf("Error type 3 at Line %d: Redefined variable \"%s\".\n", Def->lineno, field->name); // 输出错误信息
                    else
                    {                                    // 如果未找到同名的变量
                        insertSymbol(field);             // 在符号表中插入字段列表
                        field->tail = spe->u.structure_; // 将字段列表加入到结构体类型的字段列表中
                        spe->u.structure_ = field;       // 更新结构体类型的字段列表
                    }
                }
                DefList = DefList->child[1]; // 获取下一个Def节点
            }
            if (root->child[0]->child[1] != NULL)
            {                                                                                                 // 如果存在结构体标签，表示是有名结构体，需要将结构体标签加入符号表中
                FieldList field = (FieldList)malloc(sizeof(FieldList_));                                      // 分配字段列表内存
                field->type = spe;                                                                            // 设置字段列表的类型为结构体类型
                char *s = root->child[0]->child[1]->child[0]->text;                                           // 获取结构体标签节点的名称
                field->name = s;                                                                              // 设置字段列表的名称为结构体标签节点的名称
                if (lookupSymbol(field->name, 0) != NULL)                                                     // 如果在符号表中找到了同名的变量
                    printf("Error type 16 at Line %d: Duplicated name \"%s\".\n", root->lineno, field->name); // 输出错误信息
                else
                    insertSymbol(field); // 在符号表中插入字段列表
            }
            return spe; // 返回结构体类型指针
        }
    }
}

// 遍历处理外部声明列表，对全局变量和函数定义进行处理，包括添加符号表、检查重定义等操作。
void ExtDefList(Node *root)
{
    // ExtDefList → ExtDef ExtDefList | e
    // ExtDef → Specifier ExtDecList SEMI | Specifier SEMI | Specifier FunDec CompSt
    Node *ExtDefList = root; // 外部定义列表指针指向根节点
    while (ExtDefList->childsum != 0)
    {                                                    // 循环直到外部定义列表为空
        Node *ExtDef = ExtDefList->child[0];             // 获取第一个外部定义节点
        TypePtr basictype = Specifier(ExtDef->child[0]); // 获取基本类型
        // 如果外部定义是外部变量定义（ExtDecList），则处理外部变量定义列表，并将变量加入符号表。
        //ExtDecList → VarDec | VarDec COMMA ExtDecList       
        if (strcmp(ExtDef->child[1]->name, "ExtDecList") == 0)
        {                                  // 如果是外部变量定义
            Node *temp = ExtDef->child[1]; // 获取外部变量定义列表节点
            FieldList field;
            while (temp->childsum == 3)
            {                                                                                                     // 循环处理每个外部变量定义
                field = VarDec(temp->child[0], basictype);                                                        // 获取字段列表
                if (lookupSymbol(field->name, 0) != NULL)                                                         // 如果在符号表中找到了同名的变量
                    printf("Error type 3 at Line %d: Redefined variable \"%s\".\n", ExtDef->lineno, field->name); // 输出错误信息
                else
                    insertSymbol(field); // 在符号表中插入字段列表
                temp = temp->child[2];   // 移动到下一个外部变量定义
            }
            field = VarDec(temp->child[0], basictype);                                                        // 获取最后一个外部变量定义
            if (lookupSymbol(field->name, 0) != NULL)                                                         // 如果在符号表中找到了同名的变量
                printf("Error type 3 at Line %d: Redefined variable \"%s\".\n", ExtDef->lineno, field->name); // 输出错误信息
            else
                insertSymbol(field); // 在符号表中插入字段列表
        }
        // 函数定义！
        // ExtDef → Specifier FunDec CompSt
        /*
        FunDec → ID LP VarList RP | ID LP RP
        VarList → ParamDec COMMA VarList | ParamDec
        ParamDec → Specifier VarDec
        */
        else if (strcmp(ExtDef->child[1]->name, "FunDec") == 0)
        {                                                            // 如果是函数定义
            FieldList field = (FieldList)malloc(sizeof(FieldList_)); // 分配字段列表内存
            field->name = ExtDef->child[1]->child[0]->text;          // 获取函数名称
            TypePtr typ = (TypePtr)malloc(sizeof(Type_));            // 分配类型内存
            typ->kind = FUNCTION;                                    // 设置类型种类为函数类型
            typ->u.function_.funcType = basictype;                   // 设置函数返回值类型
            typ->u.function_.paramNum = 0;                           // 初始化参数数量为0
            typ->u.function_.params = NULL;                          // 初始化参数列表为空

            if (strcmp(ExtDef->child[1]->child[2]->name, "VarList") == 0)
            {                                               // 如果有参数列表
                Node *VarList = ExtDef->child[1]->child[2]; // 获取参数列表节点
                while (VarList->childsum != 1)
                {                                                                                                         // 循环处理每个参数
                    TypePtr tempType = Specifier(VarList->child[0]->child[0]);                                            // 获取参数类型
                    FieldList tempField = VarDec(VarList->child[0]->child[1], tempType);                                  // 获取参数字段列表
                    if (lookupSymbol(tempField->name, 0) != NULL)                                                         // 如果在符号表中找到了同名的变量
                        printf("Error type 3 at Line %d: Redefined variable \"%s\".\n", ExtDef->lineno, tempField->name); // 输出错误信息
                    else
                        insertSymbol(tempField);               // 在符号表中插入字段列表
                    typ->u.function_.paramNum++;               // 参数数量加一
                    tempField->tail = typ->u.function_.params; // 将参数字段列表加入到参数列表中
                    typ->u.function_.params = tempField;       // 更新参数列表
                    VarList = VarList->child[2];               // 移动到下一个参数
                }
                TypePtr tempType = Specifier(VarList->child[0]->child[0]);                                            // 获取最后一个参数的类型
                FieldList tempField = VarDec(VarList->child[0]->child[1], tempType);                                  // 获取最后一个参数的字段列表
                if (lookupSymbol(tempField->name, 0) != NULL)                                                         // 如果在符号表中找到了同名的变量
                    printf("Error type 3 at Line %d: Redefined variable \"%s\".\n", ExtDef->lineno, tempField->name); // 输出错误信息
                else
                    insertSymbol(tempField);               // 在符号表中插入字段列表
                typ->u.function_.paramNum++;               // 参数数量加一
                tempField->tail = typ->u.function_.params; // 将参数字段列表加入到参数列表中
                typ->u.function_.params = tempField;       // 更新参数列表
            }
            field->type = typ;                                                                                // 设置字段列表的类型为函数类型
            if (lookupSymbol(field->name, 1) != NULL)                                                         // 如果在符号表中找到了同名的函数
                printf("Error type 4 at Line %d: Redefined function \"%s\".\n", ExtDef->lineno, field->name); // 输出错误信息
            else
                insertSymbol(field); // 在符号表中插入字段列表

            CompSt(ExtDef->child[2], basictype); // 处理函数体
        }
        else
        { // 如果是其他类型的定义，例如声明
          // do nothing
        }

        if (ExtDefList->child[1] == NULL) // 如果没有下一个外部定义节点
            return;
        ExtDefList = ExtDefList->child[1]; // 移动到下一个外部定义节点
    }
}

// 处理函数内部的复合语句，包括处理局部变量的声明和语句块内的语句
void CompSt(Node *root, TypePtr funcType)
{
    // CompSt → LC DefList StmtList RC
    // 直接非递归解析deflist
    // stmtlist直接无脑递归处理
    Node *CompSt = root;               // 复合语句节点指针指向根节点
    DefList(CompSt->child[1]);         // 处理局部变量声明
    Node *StmtList = CompSt->child[2]; // 获取语句列表节点
    while (StmtList != NULL)
    {                                     // 循环处理每条语句
        Node *Stmt_ = StmtList->child[0]; // 获取当前语句节点
        Stmt(Stmt_, funcType);            // 处理当前语句
        StmtList = StmtList->child[1];    // 移动到下一条语句
    }
}

// 处理局部变量的定义列表，包括添加符号表、检查重定义等操作
/*
    DefList → Def DefList | e
    Def → Specifier DecList SEMI
    DecList → Dec | Dec COMMA DecList
    Dec → VarDec | VarDec ASSIGNOP Exp
*/
void DefList(Node *root)
{
    Node *DefList = root; // 定义列表指针指向根节点
    while (DefList != NULL)
    {                                                 // 循环直到定义列表为空
        Node *Def = DefList->child[0];                // 获取当前定义节点
        TypePtr basictype = Specifier(Def->child[0]); // 获取基本类型
        Node *DecList = Def->child[1];                // 获取声明列表节点
        while (DecList->childsum == 3)
        {                                                                                                      // 循环处理每个声明
            FieldList field = VarDec(DecList->child[0]->child[0], basictype);                                  // 获取字段列表
            if (lookupSymbol(field->name, 0) != NULL)                                                          // 如果在符号表中找到了同名的变量
                printf("Error type 3 at Line %d: Redefined variable \"%s\".\n", DecList->lineno, field->name); // 输出错误信息
            else
                insertSymbol(field);     // 在符号表中插入字段列表
            DecList = DecList->child[2]; // 移动到下一个声明
        }
        FieldList field = VarDec(DecList->child[0]->child[0], basictype);                                  // 获取最后一个声明
        if (lookupSymbol(field->name, 0) != NULL)                                                          // 如果在符号表中找到了同名的变量
            printf("Error type 3 at Line %d: Redefined variable \"%s\".\n", DecList->lineno, field->name); // 输出错误信息
        else
            insertSymbol(field);       // 在符号表中插入字段列表
        if (DefList->child[1] == NULL) // 如果没有下一个定义节点
            return;
        DefList = DefList->child[1]; // 移动到下一个定义节点
    }
}

// 根据语法树节点的类型，处理不同类型的语句，包括返回语句、表达式语句、复合语句、循环语句、条件语句等。
/*
   Stmt → Exp SEMI | CompSt | RETURN Exp SEMI | IF LP Exp RP Stmt | IF LP Exp RP Stmt ELSE Stmt | WHILE LP Exp RP Stmt
 */
void Stmt(Node *root, TypePtr funcType)
{
    Node *Stmt_ = root;                                                                      // 语句节点指针指向根节点
    if (strcmp(Stmt_->child[0]->name, "RETURN") == 0)                                        // RETURN Exp SEMI
    {                                                                                        // 如果是返回语句
        TypePtr returnType = Exp(Stmt_->child[1]);                                           // 获取返回值类型
        if (TypeEqual(funcType, returnType) == 0)                                            // 如果返回值类型与函数返回类型不匹配
            printf("Error type 8 at Line %d: Type mismatched for return.\n", Stmt_->lineno); // 输出错误信息
    }
    else if (strcmp(Stmt_->child[0]->name, "Exp") == 0) // Exp SEMI
    {                                                   // 如果是表达式语句
        Exp(Stmt_->child[0]);                           // 处理表达式
    }
    else if (strcmp(Stmt_->child[0]->name, "CompSt") == 0) // CompSt
    {                                                      // 如果是复合语句
        CompSt(Stmt_->child[0], funcType);                 // 处理复合语句
    }
    else if (strcmp(Stmt_->child[0]->name, "WHILE") == 0)                                                   // WHILE LP Exp RP Stmt
    {                                                                                                       // 如果是WHILE循环
        TypePtr typ = Exp(Stmt_->child[2]);                                                                 // 获取判断条件的类型
        if (!((typ->kind == BASIC) && (typ->u.basic_ == INT_TYPE)))                                         // 如果判断条件不是INT类型
            printf("Error type 5 at Line %d: Only type INT could be used for judgement.\n", Stmt_->lineno); // 输出错误信息
        Stmt(Stmt_->child[4], funcType);                                                                    // 处理循环体
    }
    else if (Stmt_->childsum < 6)
    {                                       // 如果是单独的IF语句
        TypePtr typ = Exp(Stmt_->child[2]); // 获取判断条件的类型
        if (typ != NULL)
            if (!((typ->kind == BASIC) && (typ->u.basic_ == INT_TYPE)))                                         // 如果判断条件不是INT类型
                printf("Error type 5 at Line %d: Only type INT could be used for judgement.\n", Stmt_->lineno); // 输出错误信息
        Stmt(Stmt_->child[4], funcType);                                                                        // 处理IF语句的主体
    }
    else
    {                                                                                                       // 如果是带有ELSE的IF语句
        TypePtr typ = Exp(Stmt_->child[2]);                                                                 // 获取判断条件的类型
        if (!((typ->kind == BASIC) && (typ->u.basic_ == INT_TYPE)))                                         // 如果判断条件不是INT类型
            printf("Error type 5 at Line %d: Only type INT could be used for judgement.\n", Stmt_->lineno); // 输出错误信息
        Stmt(Stmt_->child[4], funcType);                                                                    // 处理IF语句的主体
        Stmt(Stmt_->child[6], funcType);                                                                    // 处理ELSE语句的主体
    }
}

// 根据语法树节点的类型，处理不同类型的表达式，包括变量、整数、浮点数、运算符、赋值语句、函数调用、结构体成员访问、数组访问等
TypePtr Exp(Node *root)
{
    
    if (root == NULL)
        return NULL; // 如果节点为空，则返回空指针

    // Exp->ID，这应为已定义的变量
    else if ((strcmp(root->child[0]->name, "ID") == 0) && (root->childsum == 1))
    {                                                            // 如果是单个ID节点
        FieldList field = lookupSymbol(root->child[0]->text, 0); // 查找符号表中的变量
        if (field != NULL)
            return field->type; // 返回变量的类型
        else
        {
            printf("Error type 1 at Line %d: Undefined variable \"%s\".\n", root->lineno, root->child[0]->text); // 输出错误信息
            return NULL;
        }
    }

    // Exp->INT
    else if (strcmp(root->child[0]->name, "INT") == 0)
    {                                                 // 如果是整数节点
        TypePtr typ = (TypePtr)malloc(sizeof(Type_)); // 分配内存
        typ->kind = BASIC;
        typ->u.basic_ = INT_TYPE;
        return typ; // 返回整数类型
    }

    // Exp->FLOAT
    else if (strcmp(root->child[0]->name, "FLOAT") == 0)
    {                                                 // 如果是浮点数节点
        TypePtr typ = (TypePtr)malloc(sizeof(Type_)); // 分配内存
        typ->kind = BASIC;
        typ->u.basic_ = FLOAT_TYPE;
        return typ; // 返回浮点数类型
    }

    // Exp->MINUS Exp | NOT Exp | LP Exp RP
    else if ((strcmp(root->child[0]->name, "LP") == 0) || (strcmp(root->child[0]->name, "MINUS") == 0) || (strcmp(root->child[0]->name, "NOT") == 0))
    {
        return Exp(root->child[1]); // 如果是括号、负号或非运算符，则递归处理子表达式
    }

    // 这几个产生式都是形如Exp OP Exp的形式
    // 在语义分析看来它们没区别，只需要检查两边操作数类型是否是一致的INT/FLOAT即可
    // Exp STAR Exp
    // Exp DIV Exp
    // Exp PLUS Exp
    // Exp MINUS Exp
    else if ((strcmp(root->child[1]->name, "PLUS") == 0) || (strcmp(root->child[1]->name, "MINUS") == 0) || (strcmp(root->child[1]->name, "STAR") == 0) || (strcmp(root->child[1]->name, "DIV") == 0))
    {
        TypePtr typ1 = Exp(root->child[0]); // 获取左操作数的类型
        TypePtr typ2 = Exp(root->child[2]); // 获取右操作数的类型
        if (TypeEqual(typ1, typ2) == 0)
        { // 如果左右操作数类型不匹配
            if ((typ1 != NULL) && (typ2 != NULL))
                printf("Error type 7 at Line %d: Type mismatched for operands.\n", root->lineno); // 输出错误信息
            return NULL;
        }
        else
            return typ1; // 返回左操作数的类型
    }
    // Exp RELOP Exp
    // Exp AND Exp
    // Exp OR Exp
    else if ((strcmp(root->child[1]->name, "AND") == 0) || (strcmp(root->child[1]->name, "OR") == 0) || (strcmp(root->child[1]->name, "RELOP") == 0))
    {
        TypePtr typ1 = Exp(root->child[0]); // 获取左操作数的类型
        TypePtr typ2 = Exp(root->child[2]); // 获取右操作数的类型
        if (TypeEqual(typ1, typ2) == 0)
        { // 如果左右操作数类型不匹配
            if ((typ1 != NULL) && (typ2 != NULL))
                printf("Error type 7 at Line %d: Type mismatched for operands.\n", root->lineno); // 输出错误信息
            return NULL;
        }
        else
        {
            TypePtr typ = (TypePtr)malloc(sizeof(Type_)); // 分配内存
            typ->kind = BASIC;
            typ->u.basic_ = INT_TYPE;
            return typ; // 返回类型
        }
    }

    // Exp = Exp，赋值
    else if (strcmp(root->child[1]->name, "ASSIGNOP") == 0)
    {
        // 左边是变量，否则不能给他赋值
        if (root->child[0]->childsum == 1)
        {
            if (!(strcmp(root->child[0]->child[0]->name, "ID") == 0))
            {
                printf("Error type 6 at Line %d: The left-hand side of an assignment must be a variable.\n", root->lineno); // 输出错误信息
                return NULL;
            }
        }
        else if (root->child[0]->childsum == 3)
        {
            if (!((strcmp(root->child[0]->child[0]->name, "Exp") == 0) && (strcmp(root->child[0]->child[1]->name, "DOT") == 0) && (strcmp(root->child[0]->child[2]->name, "ID") == 0)))
            {
                printf("Error type 6 at Line %d: The left-hand side of an assignment must be a variable.\n", root->lineno); // 输出错误信息
                return NULL;
            }
        }
        else if (root->child[0]->childsum == 4)
        {
            if (!((strcmp(root->child[0]->child[0]->name, "Exp") == 0) && (strcmp(root->child[0]->child[1]->name, "LB") == 0) && (strcmp(root->child[0]->child[2]->name, "Exp") == 0) && (strcmp(root->child[0]->child[3]->name, "RB") == 0)))
            {
                printf("Error type 6 at Line %d: The left-hand side of an assignment must be a variable.\n", root->lineno); // 输出错误信息
                return NULL;
            }
        }
        TypePtr typ1 = Exp(root->child[0]); // 获取左操作数的类型
        TypePtr typ2 = Exp(root->child[2]); // 获取右操作数的类型
        if (TypeEqual(typ1, typ2) == 0)
        { // 如果左右操作数类型不匹配
            if ((typ1 != NULL) && (typ2 != NULL))
                printf("Error type 5 at Line %d: Type mismatched for assignment.\n", root->lineno); // 输出错误信息
            return NULL;
        }
        else
            return typ1; // 返回左操作数的类型
    }

    // Exp -> ID LP RP | ID LP Args RP  函数调用
    else if (strcmp(root->child[0]->name, "ID") == 0)
    {                                                          // 如果是ID节点
        FieldList fie = lookupSymbol(root->child[0]->text, 1); // 查找符号表中的函数
        if (fie == NULL)
        {
            FieldList fie2 = lookupSymbol(root->child[0]->text, 0);
            if (fie2 != NULL)
                printf("Error type 11 at Line %d: \"%s\" is not a function.\n", root->lineno, root->child[0]->text); // 输出错误信息
            else
                printf("Error type 2 at Line %d: Undefined function \"%s\".\n", root->lineno, root->child[0]->text); // 输出错误信息
            return NULL;
        }
        TypePtr definedType = fie->type;

        TypePtr typ = (TypePtr)malloc(sizeof(Type_)); // 分配内存
        typ->kind = FUNCTION;
        typ->u.function_.paramNum = 0;
        typ->u.function_.params = NULL;
        if (strcmp(root->child[2]->name, "RP") != 0)
        { // 如果有参数
            Node *temp = root->child[2];
            while (temp->childsum != 1)
            {                                                                // 遍历参数列表
                TypePtr tempType = Exp(temp->child[0]);                      // 获取参数类型
                FieldList tempField = (FieldList)malloc(sizeof(FieldList_)); // 分配内存
                tempField->name = "no";
                tempField->type = tempType;
                typ->u.function_.paramNum++;
                tempField->tail = typ->u.function_.params;
                typ->u.function_.params = tempField;

                temp = temp->child[2];
            }
            TypePtr tempType = Exp(temp->child[0]);                      // 获取最后一个参数的类型
            FieldList tempField = (FieldList)malloc(sizeof(FieldList_)); // 分配内存
            tempField->name = "no";                                      // 仅用于临时比较
            tempField->type = tempType;
            typ->u.function_.paramNum++;
            tempField->tail = typ->u.function_.params;
            typ->u.function_.params = tempField;
        }
        if (TypeEqual(typ, definedType) == 0)
        {
            printf("Error type 9 at Line %d: Params wrong in function \"%s\".\n", root->lineno, root->child[0]->text); // 输出错误信息
            return NULL;
        }
        else
            return definedType->u.function_.funcType; // 返回函数返回值类型
    }

    // Exp DOT ID 结构体成员访问
    else if (strcmp(root->child[1]->name, "DOT") == 0)
    {                                       // 如果是结构体成员访问节点
        TypePtr typ1 = Exp(root->child[0]); // 获取结构体变量的类型
        if (typ1->kind != STRUCTURE)
        {
            Node *temp = root->child[0];
            char *s;
           
            switch (temp->childsum)
            {
            case 1:
            {
                if (strcmp(temp->child[0]->name, "ID") == 0)
                    s = temp->child[0]->text; // 若结构体变量是一个标识符，则将其文本内容赋值给变量 s
            }
            break;
            case 3:
            {
                if (strcmp(temp->child[2]->name, "ID") == 0)
                    s = temp->child[0]->text; // 若结构体变量是通过指针访问，则将其文本内容赋值给变量 s
            }
            break;
            case 4:
            {
                if (strcmp(temp->child[0]->name, "Exp") == 0)
                    if (strcmp(temp->child[0]->child[0]->name, "ID") == 0)
                        s = temp->child[0]->child[0]->text; // 若结构体变量是通过结构体成员访问，则将其文本内容赋值给变量 s
            }
            break;
            default:
                s = "error"; // 若无法确定结构体变量类型，则将 s 设置为 "error"
                break;
            }
            if (lookupSymbol(s, 0) != NULL)
                printf("Error type 13 at Line %d: Illegal use of \".\".\n", root->lineno); // 输出错误信息
            return NULL;
        }
        char *s = root->child[2]->text;      // 获取成员名
        FieldList temp = typ1->u.structure_; // 遍历结构体成员列表
        while (temp != NULL)
        {
            if (strcmp(temp->name, s) == 0)
                return temp->type; // 返回成员类型

            temp = temp->tail;
        }

        printf("Error type 14 at Line %d: Non-existent field \"%s\".\n", root->lineno, root->child[2]->text); // 输出错误信息
        return NULL;
    }

    // Exp -> Exp LB Exp RB 数组访问
    // 例如，int a[1][1][4][5][1][4]，取a[0][0][3]是非法的，a[1][9][1][9][8][1]是合法的
    else if (strcmp(root->child[1]->name, "LB") == 0)
    {                                       // 如果是数组访问节点
        TypePtr typ1 = Exp(root->child[0]); // 获取数组变量的类型
        if (typ1->kind != ARRAY)
        {
            Node *temp = root->child[0];
            char *s;
            switch (temp->childsum)
            {
            case 1:
            {
                if (strcmp(temp->child[0]->name, "ID") == 0) // 标识符
                    s = temp->child[0]->text;
            }
            break;
            case 3:
            {
                if (strcmp(temp->child[2]->name, "ID") == 0) // 指针访问
                    s = temp->child[0]->text;
            }
            break;
            case 4:
            {
                if (strcmp(temp->child[0]->name, "Exp") == 0)
                    if (strcmp(temp->child[0]->child[0]->name, "ID") == 0) // 数组成员访问
                        s = temp->child[0]->child[0]->text;
            }
            break;
            default:
                s = "error";
                break;
            }
            if (lookupSymbol(s, 0) != NULL)
                printf("Error type 10 at Line %d: \"%s\" is not an array.\n", root->lineno, s); // 输出错误信息
            return NULL;
        }
        TypePtr temp = Exp(root->child[2]); // 获取数组索引的类型
        if (temp->kind != BASIC)
        {
            printf("Error type 12 at Line %d: there is not a integer between \"[\" and \"]\".\n", root->lineno); // 输出错误信息
            return NULL;
        }
        else if (temp->u.basic_ == FLOAT_TYPE)
        {
            printf("Error type 12 at Line %d: there is not a integer between \"[\" and \"]\".\n", root->lineno); // 输出错误信息
            return NULL;
        }
        // 无错误，返回数组元素类型
        return typ1->u.array_.elem;
    }

    else
    {
        printf("in\n"); // 输出错误信息
        return NULL;    // 返回空指针
    }
}
