#ifndef _SEMANTIC_H_ // 如果未定义语义头文件
#define _SEMANTIC_H_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "node.h" // 引入节点结构定义

#define HASH_SIZE 65536 // 哈希表大小

#define INT_TYPE 1	 // 整型类型标识
#define FLOAT_TYPE 2 // 浮点型类型标识

typedef enum Kind_
{
	BASIC,
	ARRAY,
	STRUCTURE,
	FUNCTION // 类型种类：基本类型、数组、结构体、函数
} Kind;

typedef struct Type_ *TypePtr;		  // 类型指针
typedef struct FieldList_ *FieldList; // 字段列表指针

typedef struct Type_
{
	Kind kind; // 类型种类
	union
	{
		// 基本类型
		int basic_;
		// 数组类型
		struct
		{
			int size;
			TypePtr elem; // 元素类型指针
		} array_;
		// 结构体类型
		FieldList structure_; // 字段列表指针
		// 函数类型
		struct
		{
			FieldList params; // 参数列表
			TypePtr funcType; // 函数返回值类型
			int paramNum;	  // 参数个数
		} function_;
	} u; // 联合体
} Type_;

typedef struct FieldList_
{
	char *name;		// 名称
	TypePtr type;	// 类型指针
	FieldList tail; // 下一个字段
	int collision;	// 碰撞次数 当两个不同的键经过哈希函数映射到了同一个位置上时，就会发生冲突
} FieldList_;

void traverseTree(Node *root);					 // 遍历抽象语法树
FieldList VarDec(Node *root, TypePtr basictype); // 变量声明
TypePtr Specifier(Node *root);					 // 类型说明
void ExtDefList(Node *root);					 // 外部定义列表
void CompSt(Node *root, TypePtr funcType);		 // 复合语句
void DefList(Node *root);						 // 定义列表
void Stmt(Node *root, TypePtr funcType);		 // 语句
TypePtr Exp(Node *root);						 // 表达式

unsigned int hash_pjw(char *name);				  // PJW哈希算法
void initHashtable();							  // 初始化哈希表
int insertSymbol(FieldList f);					  // 插入符号
int TypeEqual(TypePtr type1, TypePtr type2);	  // 判断类型是否相等
FieldList lookupSymbol(char *name, int function); // 查找符号
void AllSymbol();								  // 查看所有符号

#endif // 结束语义头文件的条件编译
