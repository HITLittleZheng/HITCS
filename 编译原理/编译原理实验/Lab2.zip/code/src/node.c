#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include "node.h"     // 引入节点结构定义
#include "semantic.h" // 引入语义分析函数

// 创建节点
Node *createNode(char *name, char *text)
{
    Node *pnode = (Node *)malloc(sizeof(Node));
    strcpy(pnode->name, name); // 复制节点名称
    strcpy(pnode->text, text); // 复制节点文本内容

    pnode->lineno = yylineno; // 记录节点所在行号
    for (int i = 0; i < MAX_CHILD_NUM; i++)
    {
        pnode->child[i] = NULL;
    }
    pnode->childsum = 0;
    return pnode;
}

// 添加子节点
void addChild(int childsum, Node *parent, ...)
{
    va_list ap;
    va_start(ap, parent);

    for (int i = 0; i < childsum; i++)
    {
        parent->child[i] = va_arg(ap, Node *);
    }
    parent->lineno = parent->child[0]->lineno; // 取第一个子节点的行号作为父节点行号
    parent->childsum = childsum;
    va_end(ap);
}

// 打印抽象语法树
void printTree(Node *parent, int blank)
{
    if (parent == NULL)
    {
        return;
    }
    for (int i = 0; i < blank; i++)
    {
        printf(" "); // 打印空格以缩进
    }
    if (parent->childsum != 0)
    {
        printf("%s (%d)\n", parent->name, parent->lineno); // 打印节点名称和行号
        for (int i = 0; i < parent->childsum; i++)
        {
            printTree(parent->child[i], blank + 2); // 递归打印子节点
        }
    }
    else
    {
        if (strcmp(parent->name, "INT") == 0)
        {
            printf("%s: %d\n", parent->name, atoi(parent->text)); // 打印整型值
        }
        else if (strcmp(parent->name, "FLOAT") == 0)
        {
            printf("%s: %f\n", parent->name, atof(parent->text)); // 打印浮点数值
        }
        else if (strcmp(parent->name, "ID") == 0 || strcmp(parent->name, "TYPE") == 0)
        {
            printf("%s: %s\n", parent->name, parent->text); // 打印标识符或类型名
        }
        else
        {
            printf("%s\n", parent->name); // 打印其他节点
        }
    }
}

// 遍历抽象语法树
void traverseTree(Node *root)
{
    if (root == NULL)
        return;

    if (strcmp(root->name, "ExtDefList") == 0)
    {
        ExtDefList(root); // 对外部定义列表进行语义分析
        return;
    }

    if (root->childsum != 0)
        for (int i = 0; i < root->childsum; i++)
            traverseTree(root->child[i]); // 递归遍历子节点
}
