import json
import openai

# 使用您的 API 密钥和基 URL
openai.api_key = "sk-"
openai.api_base = "https://api.deepseek.com/v1"

texts = [
    "《民航客运服务会话》是1995年中国民航出版社出版的图书，作者是周石田",
    "再有之后的《半生缘》，蒋勤勤饰演的顾曼璐完全把林心如的曼桢衬得像是涉世未深的小姑娘，毫无半点风情",
    "裴友生，男，汉族，湖北蕲春人，1957年12月出生，大专学历",
    "吴君如演的周吉是电影《花田喜事》，在周吉大婚之夜，其夫林嘉声逃走失踪，后来其夫新科状元",
    "高中回来，周吉急往城楼相识，但林嘉声却言夫妻情断，覆水难收",
]

# 存储所有实体的列表
entities_results = []

for text in texts:
    try:
        response = openai.ChatCompletion.create(
            model="deepseek-chat",
            messages=[
                {"role": "system", "content": "You are a helpful assistant trained to identify and list named entities from the text.输出结果类似这种格式{'人物'：['吴君如'，'周吉'，林嘉声']，'影视作品'：['花田喜事']}"},
                {"role": "user", "content": text}
            ],
            stream=False
        )
        # 假设返回的实体是以逗号分隔的字符串
        entities = response['choices'][0]['message']['content'].split(', ')
        entities_results.append({
            "entities": entities
        })
    except Exception as e:
        print(f"Error processing text: {text}\nError: {e}")

# 将结果保存到JSON文件
with open('entities_results.json', 'w', encoding='utf-8') as f:
    json.dump(entities_results, f, ensure_ascii=False, indent=4)

print("Entities have been saved to 'entities_results.json'")
