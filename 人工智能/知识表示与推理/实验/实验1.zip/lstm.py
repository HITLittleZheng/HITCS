import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, Dataset
import numpy as np
from collections import Counter
from torch.nn.utils.rnn import pad_sequence

# 定义一个自定义数据集类
class TextDataset(Dataset):
    def __init__(self, file_path, vocab_size, max_seq_length):
        self.vocab_size = vocab_size
        self.max_seq_length = max_seq_length
        self.words = self.load_words(file_path)
        self.vocab = self.build_vocab(self.words)
        self.tokens = self.word_to_token(self.words, self.vocab)
        self.data = self.create_sequences(self.tokens)

    def load_words(self, file_path):
        with open(file_path, 'r', encoding='ISO-8859-1') as file:
            text = file.read()
        return text.split()

    def build_vocab(self, words):
        # 统计词频
        word_freq = Counter(words)
        # 获取最常见的词直到词表大小
        vocab = [word for word, freq in word_freq.most_common(self.vocab_size)]
        return {word: idx for idx, word in enumerate(vocab)}

    def word_to_token(self, words, vocab):
        # 使用词表大小 - 1 表示未知词
        return [vocab.get(word, self.vocab_size - 1) for word in words]

    def create_sequences(self, tokens):
        sequences = [tokens[i:i + self.max_seq_length] for i in range(len(tokens) - self.max_seq_length)]
        return sequences

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        return torch.tensor(self.data[idx], dtype=torch.long)

# 定义 LSTM 模型
class LSTMModel(nn.Module):
    def __init__(self, vocab_size, embedding_dim, hidden_dim):
        super(LSTMModel, self).__init__()
        self.embedding = nn.Embedding(vocab_size, embedding_dim)
        self.lstm = nn.LSTM(embedding_dim, hidden_dim, batch_first=True)
        self.fc = nn.Linear(hidden_dim, vocab_size)

    def forward(self, x):
        x = self.embedding(x)
        output, (hidden, cell) = self.lstm(x)
        x = self.fc(output)
        return x

# 定义训练函数
def train(model, data_loader, loss_fn, optimizer, epochs):
    model.train()
    for epoch in range(epochs):
        for batch in data_loader:
            # 假设最后一个标记是前面标记的标签
            inputs, labels = batch[:, :-1], batch[:, 1:]
            outputs = model(inputs)
            loss = loss_fn(outputs.transpose(1, 2), labels)
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
        print(f'Epoch {epoch + 1}/{epochs}, Loss: {loss.item()}')

# 设置参数
vocab_size = 30000
embedding_dim = 64
hidden_dim = 64
max_seq_length = 31
epochs = 10  # 为了演示目的设置为 1，根据需要调整
batch_size = 64

# 创建数据集和数据加载器
dataset = TextDataset('./data/text.txt', vocab_size, max_seq_length)
data_loader = DataLoader(dataset, batch_size=batch_size, shuffle=True)

# 初始化模型、损失函数和优化器
model = LSTMModel(vocab_size, embedding_dim, hidden_dim)
loss_fn = nn.CrossEntropyLoss()
optimizer = optim.Adam(model.parameters())

# 训练模型
train(model, data_loader, loss_fn, optimizer, epochs)

# 保存模型
torch.save(model.state_dict(), './ckpt/language_model.pth')

print("模型训练完成并保存为 'language_model.pth'")
