import torch
import torch.nn as nn
import torch.functional as F

class TransH(nn.Module):
    def __init__(self, ent_num, rel_num, device, dim=100, norm=1, margin=2.0, alpha=0.01):
        super(TransH, self).__init__()

        self.ent_num = ent_num  # 实体数量
        self.rel_num = rel_num  # 关系数量
        self.device = device  # 设备（CPU或GPU）
        self.dim = dim  # 嵌入维度
        self.norm = norm  # 范数类型
        self.margin = margin  # 边界值
        self.alpha = alpha  # 正则化系数

        d = torch.randn(dim, 1, device=device)  # 初始化投影向量
        self.proj = nn.Parameter(d / torch.sum(d ** 2))  # 归一化投影向量

        # 初始化实体嵌入
        self.ent_embeddings = nn.Embedding(self.ent_num, self.dim).to(device)
        torch.nn.init.xavier_uniform_(self.ent_embeddings.weight.data)
        self.ent_embeddings.weight.data = self.ent_embeddings.weight.data /\
                                          F.norm(self.ent_embeddings.weight.data, 2, 1, keepdim=True)

        # 初始化关系嵌入
        self.rel_embeddings = nn.Embedding(self.rel_num, self.dim).to(device)
        torch.nn.init.xavier_uniform_(self.rel_embeddings.weight.data)
        self.rel_embeddings.weight.data = self.rel_embeddings.weight.data /\
                                          F.norm(self.rel_embeddings.weight.data, 2, 1, keepdim=True)

        # 损失函数
        self.criterion = nn.MarginRankingLoss(margin=self.margin)

    def get_ent_resps(self, ent_idx):  # 获取实体嵌入
        return self.ent_embeddings(ent_idx)  # 返回实体嵌入

    def distance(self, h_idx, r_idx, t_idx):  # 计算距离
        h_embs = self.ent_embeddings(h_idx)  # 获取头实体嵌入
        r_embs = self.rel_embeddings(r_idx)  # 获取关系嵌入
        t_embs = self.ent_embeddings(t_idx)  # 获取尾实体嵌入

        # 投影到超平面
        h_embs = h_embs - self.proj.transpose(0, 1) * (h_embs @ self.proj)  # 1, d  b, 1 -> b, d
        t_embs = t_embs - self.proj.transpose(0, 1) * (t_embs @ self.proj)

        scores = h_embs + r_embs - t_embs  # 计算得分

        norms = (torch.mean(h_embs.norm(p=self.norm, dim=1) - 1.0)
                 + torch.mean(r_embs ** 2) +
                 torch.mean(t_embs.norm(p=self.norm, dim=1) - 1.0)) / 3  # 计算正则化项
        return scores.norm(p=self.norm, dim=1), norms  # 返回得分和正则化项

    def loss(self, positive_distances, negative_distances):  # 计算损失
        target = torch.tensor([-1], dtype=torch.float, device=self.device)  # 目标标签

        return self.criterion(positive_distances, negative_distances, target)  # 返回损失

    def forward(self, pos, neg=None):  # 前向传播
        if neg is not None:  # 训练模式
            neg = neg.reshape(-1, 3)
            pos_dis = self.distance(pos[:, 0], pos[:, 2], pos[:, 1])
            neg_dis = self.distance(neg[:, 0], neg[:, 2], neg[:, 1])

            loss = self.loss(pos_dis[0], neg_dis[0]) + self.alpha * (pos_dis[1] + neg_dis[1])
            return loss
        else:  # 测试模式
            return self.distance(pos[:, 0], pos[:, 2], pos[:, 1])

import load_data

device = torch.device("cuda")  # 使用GPU

dataset = load_data.FB15K(device=device, mode="train", k=1)  # 加载训练数据

loader = load_data.DataLoader(dataset, batch_size=512, shuffle=True)  # 数据加载器
model = TransH(len(dataset.e), len(dataset.r2id), device)  # 初始化模型

# model.load_state_dict(torch.load(r"./transE.pth"))

opt = torch.optim.AdamW(model.parameters(), lr=1e-3)  # 优化器

for epoch in range(100):  # 训练循环
    for i, batch in enumerate(loader):
        pos, neg = batch
        loss = model(pos, neg)

        print(f"epoch: {epoch}, batch: {i} / {len(loader)}, loss: {loss}")

        opt.zero_grad()
        loss.backward()
        opt.step()

    # torch.save(model.state_dict(), r"./transE.pth")

    if epoch > 0 and epoch % 5 == 4:  # 每5个epoch进行一次测试

        dataset = load_data.FB15K(mode='test', k=1)  # 加载测试数据

        e = torch.tensor(range(len(dataset.e)), dtype=torch.long, device=device)
        rr = torch.tensor(range(len(dataset.r2id)), dtype=torch.long, device=device)

        hit10 = []
        mr = []

        with torch.no_grad():  # 不计算梯度
            for i, line in enumerate(dataset):
                pos, _ = line
                e1, e2, r = pos
                pos = torch.zeros(rr.shape[0], 3, dtype=torch.long, device=device)
                pos[:, 0] = e1
                pos[:, 1] = e2
                pos[:, 2] = rr
                dis = model(pos)[0]
                dis_ = dis[r]
                rank = torch.sum((dis <= dis_).float())
                mr.append(rank)
                hit10.append(float(rank <= 10))
                if i % 1000 == 0:
                    print(f"{i} / {len(dataset)}")

        print(torch.mean(torch.tensor(hit10)))  # 打印Hit@10
        print(torch.mean(torch.tensor(mr)))  # 打印平均排名

        hit10 = []
        mr = []

        with torch.no_grad():
            for i, pos in enumerate(dataset.rnn):
                e1, e2, r = pos
                pos = torch.zeros(e.shape[0], 3, dtype=torch.long, device=device)
                pos[:, 0] = e1
                pos[:, 1] = e
                pos[:, 2] = r
                dis = model(pos)[0]

                dis_ = dis[e2]
                rank = torch.sum((dis <= dis_).float())

                mr.append(rank)
                hit10.append(float(rank <= 10))
                if i % 1000 == 0:
                    print(f"{i} / {len(dataset)}")

        print(torch.mean(torch.tensor(hit10)))  # 打印Hit@10
        print(torch.mean(torch.tensor(mr)))  # 打印平均排名

        hit10 = []
        mr = []

        with torch.no_grad():
            for i, pos in enumerate(dataset.rnn):
                e1, e2, r = pos
                pos = torch.zeros(e.shape[0], 3, dtype=torch.long, device=device)
                pos[:, 0] = e
                pos[:, 1] = e2
                pos[:, 2] = r

                dis = model(pos)[0]
                dis_ = dis[e1]
                rank = torch.sum((dis <= dis_).float())
                mr.append(rank)
                hit10.append(float(rank <= 10))
                if i % 1000 == 0:
                    print(f"{i} / {len(dataset)}")

        print(torch.mean(torch.tensor(hit10)))  # 打印Hit@10
        print(torch.mean(torch.tensor(mr)))  # 打印平均排名