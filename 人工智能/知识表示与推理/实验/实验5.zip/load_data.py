from torch.utils.data import Dataset, DataLoader
import random
import torch


class WN18(Dataset):
    def __init__(self, mode='train', k=1, device=torch.device("cpu")):
        self.pth = r"D:\KG\WN18"

        self.k = k
        self.device = device

        # one-one relation
        self.r11 = []
        with open(self.pth + r"\\1-1.txt", 'r', encoding='utf-8') as f:
            for line in f:
                line = line.replace('\n', '').split(" ")
                if len(line) == 3:
                    self.r11.append([int(_) for _ in line])

        # 1-n relation
        self.r1n = []
        with open(self.pth + r"\\1-n.txt", 'r', encoding='utf-8') as f:
            for line in f:
                line = line.replace('\n', '').split(" ")
                if len(line) == 3:
                    self.r1n.append([int(_) for _ in line])

        # n-1 relation
        self.rn1 = []
        with open(self.pth + r"\\n-1.txt", 'r', encoding='utf-8') as f:
            for line in f:
                line = line.replace('\n', '').split(" ")
                if len(line) == 3:
                    self.rn1.append([int(_) for _ in line])

        # n-n relation
        self.rnn = []
        with open(self.pth + r"\\n-n.txt", 'r', encoding='utf-8') as f:
            for line in f:
                line = line.replace('\n', '').split(" ")
                if len(line) == 3:
                    self.rnn.append([int(_) for _ in line])

        # entity to id
        self.e2id = {}
        with open(self.pth + r"\\entity2id.txt", 'r', encoding='utf-8') as f:
            for line in f:
                line = line.replace('\n', '').split('\t')
                self.e2id[line[0]] = int(line[1])

        # relation to id
        self.r2id = {}
        with open(self.pth + r"\\relation2id.txt", 'r', encoding='utf-8') as f:
            for line in f:
                line = line.replace('\n', '').split('\t')
                self.r2id[line[0]] = int(line[1])

        # e1, e2, r
        self.data = []
        with open(self.pth + r"\\{}.txt".format(mode), 'r', encoding='utf-8') as f:
            for line in f:
                e1, e2, r = line.replace('\n', '').split('\t')
                self.data.append([self.e2id[e1], self.e2id[e2], self.r2id[r]])

        # all the entities
        self.e = [self.e2id[k] for k in self.e2id.keys()]

    def __len__(self):
        return len(self.data)

    def __getitem__(self, item):
        lst = self.data[item]
        pos = torch.tensor(lst, dtype=torch.long, device=self.device)   # e1, e2, r

        # random choose 2 entities
        ne1, ne2 = random.sample(self.e, 2)
        neg = torch.zeros(3, dtype=torch.long, device=self.device)
        neg[-1] = pos[2]
        neg[0] = pos[0]
        neg[1] = pos[1]

        # randomly change one or two entities
        status = random.random()
        if status > 0.2:  # both e
            neg[0] = ne1
            neg[1] = ne2
        else:
            if status > 0.6:
                neg[0] = ne1
            else:
                neg[1] = ne2

        return pos, neg


class FB15K(Dataset):
    """
        the same as WN18
    """
    def __init__(self, mode='train', k=1, device=torch.device("cpu")):
        self.pth = r"D:\KG\FB15k"

        self.k = k
        self.device = device

        self.r11 = []
        with open(self.pth + r"\\1-1.txt", 'r', encoding='utf-8') as f:
            for line in f:
                line = line.replace('\n', '').split(" ")
                if len(line) == 3:
                    self.r11.append([int(_) for _ in line])

        self.r1n = []
        with open(self.pth + r"\\1-n.txt", 'r', encoding='utf-8') as f:
            for line in f:
                line = line.replace('\n', '').split(" ")
                if len(line) == 3:
                    self.r1n.append([int(_) for _ in line])

        self.rn1 = []
        with open(self.pth + r"\\n-1.txt", 'r', encoding='utf-8') as f:
            for line in f:
                line = line.replace('\n', '').split(" ")
                if len(line) == 3:
                    self.rn1.append([int(_) for _ in line])

        self.rnn = []
        with open(self.pth + r"\\n-n.txt", 'r', encoding='utf-8') as f:
            for line in f:
                line = line.replace('\n', '').split(" ")
                if len(line) == 3:
                    self.rnn.append([int(_) for _ in line])

        self.e2id = {}
        with open(self.pth + r"\\entity2id.txt", 'r', encoding='utf-8') as f:
            for line in f:
                line = line.replace('\n', '').split('\t')
                self.e2id[line[0]] = int(line[1])

        self.r2id = {}
        with open(self.pth + r"\\relation2id.txt", 'r', encoding='utf-8') as f:
            for line in f:
                line = line.replace('\n', '').split('\t')
                self.r2id[line[0]] = int(line[1])

        self.data = []
        with open(self.pth + r"\\{}.txt".format(mode), 'r', encoding='utf-8') as f:
            for line in f:
                e1, e2, r = line.replace('\n', '').split('\t')
                self.data.append([self.e2id[e1], self.e2id[e2], self.r2id[r]])

        self.e = [self.e2id[k] for k in self.e2id.keys()]

    def __len__(self):
        return len(self.data)

    def __getitem__(self, item):
        lst = self.data[item]
        pos = torch.tensor(lst, dtype=torch.long, device=self.device)  # e1, e2, r

        ne1, ne2 = random.sample(self.e, 2)
        neg = torch.zeros(3, dtype=torch.long, device=self.device)
        neg[-1] = pos[2]
        neg[0] = pos[0]
        neg[1] = pos[1]

        status = random.random()
        if status > 0.2:  # both e
            neg[0] = ne1
            neg[1] = ne2
        else:
            # if lst in self.r1n:
            #     if status > 0.3:
            #         neg[i, 0] = ne1.pop()
            #     else:
            #         neg[i, 1] = ne2.pop()
            # elif lst in self.rn1:
            #     if status > 0.3:
            #         neg[i, 1] = ne1.pop()
            #     else:
            #         neg[i, 0] = ne2.pop()
            # else:
            if status > 0.6:
                neg[0] = ne1
            else:
                neg[1] = ne2

        return pos, neg

# for d in FB15K():
#     p, n = d
#     print(p)
#     print(n)
#     print("\n\n")
#     input()
