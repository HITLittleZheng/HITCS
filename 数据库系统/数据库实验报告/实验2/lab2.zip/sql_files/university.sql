DROP DATABASE IF EXISTS `university`;
CREATE DATABASE `university`;
USE `university`;