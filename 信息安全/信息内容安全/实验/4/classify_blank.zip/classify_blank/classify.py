# coding: utf-8
import re

import jieba
import joblib
from sklearn.feature_extraction.text import HashingVectorizer

from multinomial_nb import MultinomialNaiveBayes


def calssify(text):
    # Multinomial Naive Bayes Classifier
    clf = MultinomialNaiveBayes()
    clf = joblib.load('model/' + str(type(clf))[8:-2] + '.model')

    with open('dict/stopwords.txt', 'r', encoding='utf-8', errors='ignore') as f:
        stopwords = [w.strip() for w in f if w.strip()]  # 使用列表并过滤空字符串
    v = HashingVectorizer(alternate_sign=False, stop_words=stopwords, n_features=30000)

    text = text.replace('\n', ' ')
    text = text.replace('\t', ' ')
    text = ' '.join(jieba.cut(text, cut_all=False))
    text = re.sub(u'[$^()-=~！@#￥%……&*（）——+·{}|：“”《》？【】、；‘’，。、]', u'', text)

    text = text.encode('utf-8')
    test_data = v.fit_transform([text])

    pred = clf.predict(test_data)
    return pred[0][0]


if __name__ == '__main__':
    r_dict = {
        '0': u'汽车',
        '1': u'财经',
        '2': u'科技',
        '3': u'健康',
        '4': u'体育',
    }

    r = calssify('''
        
        长安2021款CS75 PLUS新增一款自动先锋型配置车型，其售价为11.79万元。新车外观与现款基本保持一致，主要对细节进行了调整，如格栅加装了红色元素进行点缀。配置方面，新车在自动精英型配置基础上，新增了LED远近光一体式冰晶大灯、冰裂纹V型LED日行灯、城市之光贯穿式前位灯、迎宾灯、无钥匙进入系统以及单温区自动空调等功能配置。动力上搭载了1.5T发动机，其最大功率131kW，最大扭矩265Nm。传动系统匹配6速手自一体变速箱。

    ''')
    print(r, r_dict[r])
