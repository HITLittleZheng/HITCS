package myRSA;

import java.math.BigInteger;
import java.util.Random;
import java.util.Scanner;
import myFast.FastModularExpo;
public class RSA {

    // 生成大素数
    public static BigInteger getPrime(int bitCount) {
        return BigInteger.probablePrime(bitCount, new Random());//随机生成一个大素数，bitCount对位数进行定义
    }

    // 生成公私钥
    public static BigInteger[] generateKey(int bits) {
        BigInteger p = getPrime(bits / 2);
        BigInteger q = getPrime(bits / 2);
        BigInteger n = p.multiply(q);
        BigInteger phi = p.subtract(BigInteger.ONE).multiply(q.subtract(BigInteger.ONE));

        BigInteger e = BigInteger.valueOf(65537); // 公钥值取65537
        while (phi.gcd(e).intValue() > 1) {
            e = e.add(new BigInteger("2"));
        }

        BigInteger d = e.modInverse(phi);

        return new BigInteger[]{e, d, n};
    }

    // 加密
    public static BigInteger encrypt(BigInteger plaintext, BigInteger e, BigInteger n) {
        return FastModularExpo.fastModPow(plaintext, e, n);
    }

    // 解密
    public static BigInteger decrypt(BigInteger ciphertext, BigInteger d, BigInteger n) {
        return FastModularExpo.fastModPow(ciphertext, d, n);
    }

    // 主函数
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("请输入安全参数 bits: ");
        int bits = scanner.nextInt();

        System.out.print("请输入要加密的明文: ");
        BigInteger plaintext = scanner.nextBigInteger();

        BigInteger[] keys = generateKey(bits);
        BigInteger e = keys[0];
        BigInteger d = keys[1];
        BigInteger n = keys[2];

        System.out.println("公钥 (e, n): (" + e + ", " + n + ")");
        System.out.println("私钥 (d, n): (" + d + ", " + n + ")");

        BigInteger ciphertext = encrypt(plaintext, e, n);
        System.out.println("加密后的密文: " + ciphertext);

        BigInteger decryptedText = decrypt(ciphertext, d, n);
        System.out.println("解密后的明文: " + decryptedText);

        scanner.close();
    }
}
