import java.math.BigInteger;
import java.nio.ByteBuffer;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;
import myRSA.RSA;//自己写的RSA算法

public class RSA_OAEP {

    // 生成指定长度的大素数
    public BigInteger getPrime(int bitCount) {
        return BigInteger.probablePrime(bitCount, new Random());//同样的，生成一个大素数
    }

    // 生成加密解密所需要的公、私密钥对
    public BigInteger[] generateKey(int bits) {
       return RSA.generateKey(bits);//调用刚才写的RSA函数的生成密钥方法
    }

    // 生成掩码
    public byte[] MGF(byte[] X, int maskLen) throws NoSuchAlgorithmException {//错误的时候要抛出异常才行
        //X是seed，masklen是掩码长度
        MessageDigest md = MessageDigest.getInstance("SHA-256");//用SHA-256算法进行生成一个消息摘要
        byte[] T = new byte[maskLen];//存储最终的掩码
        int counter = 0;
        byte[] C = new byte[4];
        int hLen = md.getDigestLength();//获取digest的长度

        while (counter < (maskLen / hLen)) {
            ByteBuffer.wrap(C).putInt(counter);//将计数器的值转换为字节然后存储在C中
            md.update(X);//更新消息摘要，加入输入种子，然后加入C
            md.update(C);
            System.arraycopy(md.digest(), 0, T, counter * hLen, hLen);//把消息摘要复制到T
            counter++;
        }

        if (maskLen % hLen != 0) {//处理最后部分
            ByteBuffer.wrap(C).putInt(counter);
            md.update(X);
            md.update(C);
            System.arraycopy(md.digest(), 0, T, counter * hLen, maskLen % hLen);
        }

        return T;
    }

    // 消息填充算法
    public byte[] encode(byte[] plainOAEP/*原始参数*/, String L, int k/*RSA秘钥长度*/) throws NoSuchAlgorithmException {
        MessageDigest md = MessageDigest.getInstance("SHA-256");//初始化消息摘要
        byte[] lHash = md.digest(L.getBytes());//计算md的hash值
        int hLen = lHash.length;
        int mLen = plainOAEP.length;

        if (k < (mLen + 2 * hLen + 2)) {
            throw new IllegalArgumentException("Encoding error, message too long.");
        }

        byte[] PS = new byte[k - mLen - 2 * hLen - 2];
        byte[] DB = ByteBuffer.allocate(k - hLen - 1)
                .put(lHash)
                .put(PS)
                .put((byte) 0x01)
                .put(plainOAEP)
                .array();
        //创建数据块 `DB`，包含 `lHash`、`PS`、一个字节的 `0x01` 和原始消息。
        byte[] seed = new byte[hLen];//创建种子
        new SecureRandom().nextBytes(seed);//随机填充种子
        byte[] dbMask = MGF(seed, k - hLen - 1);//用MGF生成数据块掩码
        byte[] maskedDB = new byte[dbMask.length];

        for (int i = 0; i < dbMask.length; i++) {
            maskedDB[i] = (byte) (DB[i] ^ dbMask[i]);//异或操作将dbMask应用于DB
        }
        //掩码种子
        byte[] seedMask = MGF(maskedDB, hLen);
        byte[] maskedSeed = new byte[seed.length];

        for (int i = 0; i < seed.length; i++) {
            maskedSeed[i] = (byte) (seed[i] ^ seedMask[i]);
        }

        return ByteBuffer.allocate(1 + maskedSeed.length + maskedDB.length)
                .put((byte) 0x00)
                .put(maskedSeed)
                .put(maskedDB)
                .array();
    }

    // OAEP 加密
//    public BigInteger encryptOAEP(byte[] plainOAEP, String L, int k, BigInteger e, BigInteger n) throws NoSuchAlgorithmException {
//        byte[] EM = encode(plainOAEP, L, k);
//        BigInteger m = new BigInteger(1, EM); // 确保 BigInteger 是正数
//        BigInteger c = m.modPow(e, n);
//
//        // 将 BigInteger 转换为字节数组，并确保长度与 k 相匹配
//        byte[] cipherBytes = c.toByteArray();
//        if (cipherBytes.length < k) {
//            byte[] temp = new byte[k];
//            System.arraycopy(cipherBytes, 0, temp, k - cipherBytes.length, cipherBytes.length);
//            cipherBytes = temp;
//        }
//
//        return new BigInteger(cipherBytes);
//    }
    public BigInteger encryptOAEP(byte[] plainOAEP, String L, int k, BigInteger e, BigInteger n) throws NoSuchAlgorithmException {
        byte[] EM = encode(plainOAEP, L, k);
        BigInteger m = new BigInteger(1, EM); // 确保 BigInteger 是正数

        // 使用自己写的 RSA 加密方法
        BigInteger c = RSA.encrypt(m, e, n);

        // 将 BigInteger 转换为字节数组，并确保长度与 k 相匹配
        byte[] cipherBytes = c.toByteArray();
        if (cipherBytes.length < k) {
            byte[] temp = new byte[k];
            System.arraycopy(cipherBytes, 0, temp, k - cipherBytes.length, cipherBytes.length);
            cipherBytes = temp;
        }

        return new BigInteger(cipherBytes);
    }

    // 解码（去掉填充）
    public byte[] decode(byte[] EM/*加密后的消息*/, String L, int k/*秘钥的长度*/) throws NoSuchAlgorithmException {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        byte[] lHash = md.digest(L.getBytes());
        int hLen = lHash.length;

        if (EM.length != k || k < 2 * hLen + 2) {
            throw new IllegalArgumentException("Decoding error, incorrect message length.");
        }

        byte Y = EM[0];//提取第一个字节0x00
        byte[] maskedSeed = Arrays.copyOfRange(EM, 1, hLen + 1);//根据算法 提取掩码后的种子
        byte[] maskedDB = Arrays.copyOfRange(EM, hLen + 1, EM.length);//提取掩码后的数据块

        byte[] seedMask = MGF(maskedDB, hLen);//利用MGF和maskedDB生成种子掩码
        byte[] seed = new byte[hLen];
        for (int i = 0; i < hLen; i++) {//还原db
            seed[i] = (byte) (maskedSeed[i] ^ seedMask[i]);
        }

        byte[] dbMask = MGF(seed, k - hLen - 1);
        byte[] DB = new byte[dbMask.length];
        for (int i = 0; i < dbMask.length; i++) {
            DB[i] = (byte) (maskedDB[i] ^ dbMask[i]);
        }
        //vertify the hash
        if (!Arrays.equals(Arrays.copyOfRange(DB, 0, hLen), lHash)) {
            throw new IllegalArgumentException("Decoding error, lHash mismatch.");
        }

        int index = hLen;
        while (index < DB.length && DB[index] == 0) {
            index++;
        }
        //找到DB第一个非零字节后的部分，就是原始消息
        if (index == DB.length || DB[index] != 1) {
            throw new IllegalArgumentException("Decoding error, incorrect padding.");
        }

        return Arrays.copyOfRange(DB, index + 1, DB.length);
    }

    //解密
    public byte[] decrypt(BigInteger cipherOAEP, String L, int k, BigInteger d, BigInteger n) throws NoSuchAlgorithmException {
        BigInteger c = cipherOAEP;
//        BigInteger m = c.modPow(d, n);
        BigInteger m = RSA.decrypt(c,d,n);
        byte[] decryptedBytes = m.toByteArray();
        if (decryptedBytes.length < k) {
            byte[] temp = new byte[k];
            System.arraycopy(decryptedBytes, 0, temp, k - decryptedBytes.length, decryptedBytes.length);
            decryptedBytes = temp;
        }

        return decode(decryptedBytes, L, k);
    }

    public static void main(String[] args) throws NoSuchAlgorithmException {
        RSA_OAEP rsa = new RSA_OAEP();
        Scanner scanner = new Scanner(System.in);

        // 输入比特数
        System.out.print("Enter the bit count for RSA key generation: ");
        int bitCount = scanner.nextInt();

        // 生成公钥和私钥
        BigInteger[] keys = rsa.generateKey(bitCount);
        BigInteger e = keys[0]; // 公钥 e
        BigInteger d = keys[1]; // 私钥 d
        BigInteger n = keys[2]; // 公钥和私钥共用 n

        System.out.print("Enter the message to encrypt: ");
        scanner.nextLine();
        String message = scanner.nextLine();

        // 加密
        byte[] encrypted = rsa.encryptOAEP(message.getBytes(), "", n.bitLength() / 8, e, n).toByteArray();
        System.out.println("Encrypted message: " + Arrays.toString(encrypted));

        // 解密
        byte[] decrypted = rsa.decrypt(new BigInteger(encrypted), "", n.bitLength() / 8, d, n);
        System.out.println("Decrypted message: " + new String(decrypted));
    }
}
